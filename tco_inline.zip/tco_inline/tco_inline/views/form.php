<br/>
<span id="tcoInlineForm"
      data-pid="<?php echo $virtuemart_paymentmethod_id; ?>"
      data-seller="<?php echo $seller_id; ?>"
      data-order='<?php echo JRoute::_('index.php?option=com_virtuemart&view=cart&task=orderdone'); ?>'

    <input type="hidden" id="ess_token" name="ess_token" value="">

</span>
